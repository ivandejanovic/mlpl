#!/bin/bash

./mlpl $* espanol.cfg
