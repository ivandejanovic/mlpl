#!/bin/bash

./mlpl $* english.cfg
