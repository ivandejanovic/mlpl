#!/bin/bash

./mlpl $* srpski.cfg
